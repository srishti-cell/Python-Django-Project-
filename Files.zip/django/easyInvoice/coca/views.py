from django.shortcuts import render

def index(request):
    # Your view logic goes here
    return render(request, 'your_template.html')

def gen_pdf(request):
    if request.method == 'POST':
        # Retrieve quantity values from the form
        lipfrog_quantity = int(request.POST.get('Lip frog', 0))
        davidoff_quantity = int(request.POST.get('Davidoff', 0))
        estee_lauder_quantity = int(request.POST.get('EsteeLauder', 0))
        scentric_quantity = int(request.POST.get('Scentric', 0))

        # Calculate total amount
        total_amount = 200 * lipfrog_quantity + 300 * davidoff_quantity + 100 * estee_lauder_quantity + 500 * scentric_quantity

        # Render the template with the total amount
        return render(request, 'your_template.html', {'total_amount': total_amount})

    return render(request, 'your_template.html')


